package com.example.hello;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import android.os.Handler;

public class AddFoodBank extends BaseActivity implements MapSelectionDialog.OnLocationSelectedListener {
    private TextView locationTextView;
    private TextInputEditText nameEditText, addressEditText, contactEditText, emailEditText;
    private Button selectLocationButton, submitButton;
    private LatLng selectedLocation;
    private Geocoder geocoder;
    private Handler mainHandler;
    private static final int GEOCODER_TIMEOUT = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_add_food_bank);

        initializeViews();
        setupListeners();
        geocoder = new Geocoder(this, new Locale("ms", "MY")); // Malay locale
        mainHandler = new Handler(Looper.getMainLooper());
    }

    private void initializeViews() {
        locationTextView = findViewById(R.id.tv_coordinates);
        nameEditText = findViewById(R.id.et_name);
        addressEditText = findViewById(R.id.et_address);
        contactEditText = findViewById(R.id.et_contact);
        emailEditText = findViewById(R.id.et_email);
        selectLocationButton = findViewById(R.id.btn_select_location);
        submitButton = findViewById(R.id.btn_submit);
    }

    private void setupListeners() {
        selectLocationButton.setOnClickListener(v -> showMapDialog());
        submitButton.setOnClickListener(v -> submitFoodBank()); // Call submitFoodBank() here
    }

    private void submitFoodBank() {
        if (!validateInput()) {
            return;
        }

        String name = nameEditText.getText().toString().trim();
        String address = addressEditText.getText().toString().trim();
        String contact = contactEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        float rating = 4.5f; // Default rating or obtain from user input

        // Create a map of foodbank data
        Map<String, Object> foodBankData = new HashMap<>();
        foodBankData.put("name", name);
        foodBankData.put("address", address);
        foodBankData.put("phoneNumber", contact);
        foodBankData.put("email", email);
        foodBankData.put("rating", rating);
        foodBankData.put("location", new GeoPoint(selectedLocation.latitude, selectedLocation.longitude));

        // Get Firestore instance
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Add document to Firestore
        db.collection("foodbank")
                .add(foodBankData)
                .addOnSuccessListener(documentReference -> {
                    // Get the auto-generated ID
                    String foodBankId = documentReference.getId();

                    // Create Intent with all data including the new ID
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("id", foodBankId);
                    resultIntent.putExtra("name", name);
                    resultIntent.putExtra("address", address);
                    resultIntent.putExtra("phoneNumber", contact);
                    resultIntent.putExtra("email", email);
                    resultIntent.putExtra("rating", rating);
                    resultIntent.putExtra("latitude", selectedLocation.latitude);
                    resultIntent.putExtra("longitude", selectedLocation.longitude);

                    setResult(RESULT_OK, resultIntent);
                    Toast.makeText(this, "Food bank added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error adding food bank: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private boolean validateInput() {
        if (selectedLocation == null) {
            Toast.makeText(this, "Please select a location", Toast.LENGTH_SHORT).show();
            return false;
        }

        String name = nameEditText.getText().toString().trim();
        String address = addressEditText.getText().toString().trim();
        String contact = contactEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();

        if (name.isEmpty() || address.isEmpty() || contact.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void showMapDialog() {
        MapSelectionDialog dialog = new MapSelectionDialog();
        dialog.setOnLocationSelectedListener(this);
        dialog.show(getSupportFragmentManager(), "map_selection");
    }

    @Override
    public void onLocationSelected(LatLng location) {
        selectedLocation = location;
        updateLocationDisplay(location);
        // Run geocoding in background
        getAddressFromLocationAsync(location);
    }

    private void getAddressFromLocationAsync(LatLng location) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<String> future = executor.submit(() -> {
            try {
                // Use both English and Malay locales for better results
                List<Address> addresses = geocoder.getFromLocation(
                        location.latitude, location.longitude, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);

                    // Build a complete address string
                    StringBuilder fullAddress = new StringBuilder();

                    // Get the street address
                    String addressLine = address.getAddressLine(0);
                    if (addressLine != null) {
                        fullAddress.append(addressLine);
                    } else {
                        // Fallback to building address manually
                        String featureName = address.getFeatureName();
                        String thoroughfare = address.getThoroughfare();
                        String subLocality = address.getSubLocality();
                        String locality = address.getLocality();
                        String postalCode = address.getPostalCode();
                        String state = address.getAdminArea();

                        if (thoroughfare != null) fullAddress.append(thoroughfare).append(", ");
                        if (subLocality != null) fullAddress.append(subLocality).append(", ");
                        if (postalCode != null) fullAddress.append(postalCode).append(" ");
                        if (locality != null) fullAddress.append(locality).append(", ");
                        if (state != null) fullAddress.append(state);
                    }

                    return fullAddress.toString().trim();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        });

        // Handle timeout and result
        try {
            String address = future.get(GEOCODER_TIMEOUT, TimeUnit.MILLISECONDS);
            mainHandler.post(() -> {
                if (address != null && !address.isEmpty()) {
                    addressEditText.setText(address);
                } else {
                    addressEditText.setText("");
                    Toast.makeText(this, "Unable to get complete address. Please enter manually.",
                            Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            mainHandler.post(() -> {
                addressEditText.setText("");
                Toast.makeText(this, "Error getting address. Please enter manually.",
                        Toast.LENGTH_SHORT).show();
            });
        }
        executor.shutdown();
    }

    private void updateLocationDisplay(LatLng latLng) {
        String coordinates = String.format(Locale.getDefault(),
                "Selected Location: %.6f, %.6f",
                latLng.latitude, latLng.longitude);
        locationTextView.setText(coordinates);
    }
}