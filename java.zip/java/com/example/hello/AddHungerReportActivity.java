package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class AddHungerReportActivity extends AppCompatActivity {

    private EditText etFamilyMembers, etLocation, etDay, etDate, etIncomeLevel, etRemarks, etContactNumber;
    private Button btnAddHungerReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addhungerreporting);

        initializeViews();
        setupClickListener();
    }

    private void initializeViews() {
        etFamilyMembers = findViewById(R.id.addfamilyMembers);
        etLocation = findViewById(R.id.addLoc);
        etDay = findViewById(R.id.addDay);
        etDate = findViewById(R.id.addDate);
        etIncomeLevel = findViewById(R.id.addIncome);
        etRemarks = findViewById(R.id.addRemarks);
        etContactNumber = findViewById(R.id.addContactNumber);
        btnAddHungerReport = findViewById(R.id.addHRButton);
    }

    private void setupClickListener() {
        btnAddHungerReport.setOnClickListener(v -> {
            if (validateInputs()) {
                saveAndFinish();
            }
        });
    }

    private boolean validateInputs() {
        String contactNumber = etContactNumber.getText().toString().trim();
        if (contactNumber.isEmpty()) {
            etContactNumber.setError("Contact number is required");
            return false;
        }
//        if (!isValidPhoneNumber(contactNumber)) {
//            etContactNumber.setError("Please enter a valid phone number");
//            return false;
//        }
        return true;
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("^(01)[0-46-9]-*[0-9]{7,8}$");
    }

    private void saveAndFinish() {
        String familyMembers = etFamilyMembers.getText().toString();
        String location = etLocation.getText().toString();
        String day = etDay.getText().toString();
        String date = etDate.getText().toString();
        String incomeLevel = etIncomeLevel.getText().toString();
        String remarks = etRemarks.getText().toString();
        String contactNumber = etContactNumber.getText().toString();

        HungerReporting report = new HungerReporting(
                familyMembers, location, day, date, incomeLevel, remarks, contactNumber
        );

        // Send data back to the calling activity
        Intent intent = new Intent();
        intent.putExtra("FamilyMembers", familyMembers);
        intent.putExtra("Location", location);
        intent.putExtra("Day", day);
        intent.putExtra("Date", date);
        intent.putExtra("IncomeLevel", incomeLevel);
        intent.putExtra("Remarks", remarks);
        intent.putExtra("ContactNumber", contactNumber);

        saveHungerReportToFirestore(report);
        setResult(RESULT_OK, intent);

    }

    private void saveHungerReportToFirestore(HungerReporting report) {
        FirebaseAuth auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            String userId = auth.getCurrentUser().getUid();
            String userEmail = auth.getCurrentUser().getEmail();

            Map<String, Object> reportMap = new HashMap<>();
            reportMap.put("familyMembers", report.getFamilymembers());
            reportMap.put("location", report.getLocation());
            reportMap.put("day", report.getDay());
            reportMap.put("date", report.getDateHR());
            reportMap.put("incomeLevel", report.getIncomeLevel());
            reportMap.put("remarks", report.getRemarks());
            reportMap.put("contactNumber", report.getContactNumber());  // Make sure this matches
            reportMap.put("userId", userId);
            reportMap.put("userEmail", userEmail);
            reportMap.put("timestamp", System.currentTimeMillis());

            FirebaseFirestore.getInstance()
                    .collection("hunger_reports")
                    .add(reportMap)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(this, "Hunger report added successfully!", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error adding report: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(this, "User not authenticated!", Toast.LENGTH_SHORT).show();
        }
    }
}
