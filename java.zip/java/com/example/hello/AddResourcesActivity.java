package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.example.hello.R;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddResourcesActivity extends BaseActivity {

    private EditText articleName, briefDesc, url;
    private Button btnAddResource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_addresources);

        // Initialize views
        articleName = findViewById(R.id.addArticleName);
        briefDesc = findViewById(R.id.addBriefDesc);
        url = findViewById(R.id.addURL);
        btnAddResource= findViewById(R.id.addResource);

        btnAddResource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ArticleName = articleName.getText().toString();
                String BriefDesc = briefDesc.getText().toString();
                String URL = url.getText().toString();

                Intent intent = new Intent();
                intent.putExtra("Article Name", ArticleName);
                intent.putExtra("Brief Description", BriefDesc);
                intent.putExtra("URL", URL);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}

