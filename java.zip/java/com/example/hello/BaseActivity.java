package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class BaseActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);

        // Toolbar setup
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // DrawerLayout and toggle setup
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Bottom navigation setup
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.DestFoodBank) {
                startActivity(new Intent(BaseActivity.this, HomeActivity.class));
                return true;
            } else if (itemId == R.id.DestHungerReporting) {
                startActivity(new Intent(BaseActivity.this, HungerReportingActivity.class));
                return true;
            } else if (itemId == R.id.DestResources) {
                startActivity(new Intent(BaseActivity.this, ResourcesActivity.class));
                return true;
            } else if (itemId == R.id.DestCommunitySharing) {
                startActivity(new Intent(BaseActivity.this, CommunitySharing.class));
                return true;
            } else {
                return false;
            }
        });

        // Side navigation setup
        NavigationView sideNavigationView = findViewById(R.id.side_navigation);
        sideNavigationView.setNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.DestSettings) {
                startActivity(new Intent(BaseActivity.this, SettingsActivity.class));
                return true;
            } else {
                return false;
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    // To dynamically set content in the BaseActivity
    protected void setActivityContent(int layoutResID) {
        FrameLayout content = findViewById(R.id.activity_content);
        getLayoutInflater().inflate(layoutResID, content);
    }
}