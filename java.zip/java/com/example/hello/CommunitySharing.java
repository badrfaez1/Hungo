package com.example.hello;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class CommunitySharing extends BaseActivity {

    private SharedFoodAdapter adapter;
    private List<SharedFoodItem> shareFoodList;
    private ActivityResultLauncher<Intent> addCommFoodLauncher;
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_community_sharing);

        initializeFirebase();
        initializeViews();
        setupRecyclerView();
        setupActivityLauncher();
        loadSharedFoods();
    }

    private void initializeFirebase() {
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }

    private void initializeViews() {
        FloatingActionButton addFood = findViewById(R.id.addCommShare);
        addFood.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreatePostActivity.class);
            addCommFoodLauncher.launch(intent);  // Use the launcher to start the activity
        });
    }

    private void setupRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.commshare_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        shareFoodList = new ArrayList<>();
        adapter = new SharedFoodAdapter(shareFoodList);
        recyclerView.setAdapter(adapter);
    }

    private void setupActivityLauncher() {
        addCommFoodLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        String foodName = data.getStringExtra("Food Name");
                        String foodDescription = data.getStringExtra("Food Description");
                        String expiryDate = data.getStringExtra("Food Expiry");
                        String contactNumber = data.getStringExtra("Contact Number");

                        SharedFoodItem newFood = new SharedFoodItem(
                                foodName, foodDescription, expiryDate, contactNumber
                        );
                        shareFoodList.add(newFood);
                        adapter.notifyItemInserted(shareFoodList.size() - 1);
                    }
                }
        );
    }

    private void loadSharedFoods() {
        shareFoodList.clear();
        adapter.notifyDataSetChanged();

        db.collection("shared_foods")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Error loading shared foods: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (snapshots != null) {
                        shareFoodList.clear();
                        for (QueryDocumentSnapshot document : snapshots) {
                            String foodName = document.getString("foodName");
                            String foodDescription = document.getString("foodDescription");
                            String foodExpiry = document.getString("foodExpiry");
                            String contactNumber = document.getString("contactNumber");
                            String userId = document.getString("userId");

                            SharedFoodItem food = new SharedFoodItem(
                                    foodName, foodDescription, foodExpiry, contactNumber
                            );
                            food.setId(document.getId());  // Set the document ID
                            food.setUserId(userId);       // Set the user ID
                            shareFoodList.add(food);
                        }
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadSharedFoods(); // Refresh the list when activity resumes
    }
}