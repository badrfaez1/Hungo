package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class CreatePostActivity extends BaseActivity {
    private EditText foodName, foodDescription, expiry, contactNum;
    private Button btnAddFood;
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_create_post);

        initializeFirebase();
        initializeViews();
        setupClickListeners();
    }

    private void initializeFirebase() {
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }

    private void initializeViews() {
        foodName = findViewById(R.id.addFoodName);
        foodDescription = findViewById(R.id.addDescFood);
        expiry = findViewById(R.id.ExpiryDate);
        contactNum = findViewById(R.id.contactNumFooddd);
        btnAddFood = findViewById(R.id.addCommunity);
    }

    private void setupClickListeners() {
        btnAddFood.setOnClickListener(v -> validateAndSaveFood());
    }

    private void validateAndSaveFood() {
        String name = foodName.getText().toString().trim();
        String description = foodDescription.getText().toString().trim();
        String expiryDate = expiry.getText().toString().trim();
        String contact = contactNum.getText().toString().trim();

        if (!validateInputs(name, description, expiryDate, contact)) {
            return;
        }

        SharedFoodItem newFood = new SharedFoodItem(name, description, expiryDate, contact);
        saveResourceToFirestore(newFood);
    }

    private boolean validateInputs(String name, String description, String expiryDate, String contact) {
        if (name.isEmpty()) {
            foodName.setError("Food name is required");
            return false;
        }
        if (description.isEmpty()) {
            foodDescription.setError("Description is required");
            return false;
        }
        if (expiryDate.isEmpty()) {
            expiry.setError("Expiry date is required");
            return false;
        }
        if (contact.isEmpty()) {
            contactNum.setError("Contact number is required");
            return false;
        }
//        if (!isValidPhoneNumber(contact)) {
//            contactNum.setError("Please enter a valid phone number");
//            return false;
//        }
        return true;
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        // Basic validation for Malaysian phone numbers
        return phoneNumber.matches("^(01)[0-46-9]-*[0-9]{7,8}$");
    }

    private void saveResourceToFirestore(SharedFoodItem food) {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Please sign in to share food", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = auth.getCurrentUser().getUid();
        String userEmail = auth.getCurrentUser().getEmail();

        Map<String, Object> foodMap = new HashMap<>();
        foodMap.put("foodName", food.getFoodName());
        foodMap.put("foodDescription", food.getDescription());
        foodMap.put("foodExpiry", food.getExpiryDate());
        foodMap.put("contactNumber", food.getContactNumber());
        foodMap.put("userId", userId);
        foodMap.put("userEmail", userEmail);
        foodMap.put("timestamp", System.currentTimeMillis());

        db.collection("shared_foods")
                .add(foodMap)
                .addOnSuccessListener(documentReference -> {
                    setSuccessResult(food);
                    Toast.makeText(this, "Food shared successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error sharing food: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void setSuccessResult(SharedFoodItem food) {
        Intent intent = new Intent();
        intent.putExtra("Food Name", food.getFoodName());
        intent.putExtra("Food Description", food.getDescription());
        intent.putExtra("Food Expiry", food.getExpiryDate());
        intent.putExtra("Contact Number", food.getContactNumber());
        intent.putExtra("User ID", food.getUserId());

        setResult(RESULT_OK, intent);
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }
}