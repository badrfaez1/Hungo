package com.example.hello;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.util.Log;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolylineOptions;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class FetchDirectionsTask extends AsyncTask<String, Void, List<LatLng>> {
    private static final String TAG = "FetchDirectionsTask";
    private final Context context;
    private final GoogleMap googleMap;
    private final LatLng origin;
    private final LatLng destination;

    public FetchDirectionsTask(Context context, GoogleMap googleMap, LatLng origin, LatLng destination) {
        this.context = context;
        this.googleMap = googleMap;
        this.origin = origin;
        this.destination = destination;
    }

    @Override
    protected List<LatLng> doInBackground(String... urls) {
        if (urls.length == 0) {
            Log.e(TAG, "No URL provided");
            return null;
        }

        try {
            String data = downloadUrl(urls[0]);
            return parseDirections(data);
        } catch (IOException e) {
            Log.e(TAG, "Error downloading directions", e);
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Unexpected error fetching directions", e);
            return null;
        }
    }

    @Override
    protected void onPostExecute(List<LatLng> points) {
        if (points == null || points.isEmpty()) {
            Log.w(TAG, "No route points received, drawing direct line");
            // Fall back to direct line if no route is found
            drawDirectLine();
            return;
        }

        try {
            PolylineOptions polylineOptions = new PolylineOptions()
                    .addAll(points)
                    .width(12)
                    .color(Color.BLUE)
                    .geodesic(true);

            googleMap.addPolyline(polylineOptions);
        } catch (Exception e) {
            Log.e(TAG, "Error drawing polyline", e);
            drawDirectLine();
        }
    }

    private void drawDirectLine() {
        try {
            PolylineOptions directLine = new PolylineOptions()
                    .add(origin)
                    .add(destination)
                    .width(12)
                    .color(Color.BLUE)
                    .geodesic(true);

            googleMap.addPolyline(directLine);
        } catch (Exception e) {
            Log.e(TAG, "Error drawing direct line", e);
        }
    }

    private String downloadUrl(String urlStr) throws IOException {
        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        StringBuilder result = new StringBuilder();

        try {
            URL url = new URL(urlStr);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(15000);
            urlConnection.setReadTimeout(15000);
            urlConnection.connect();

            int responseCode = urlConnection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new IOException("HTTP error code: " + responseCode);
            }

            inputStream = urlConnection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    Log.e(TAG, "Error closing input stream", e);
                }
            }
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        return result.toString();
    }

    private List<LatLng> parseDirections(String jsonData) {
        List<LatLng> points = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(jsonData);

            // Check status first
            String status = jsonObject.getString("status");
            if (!"OK".equals(status)) {
                Log.w(TAG, "Directions API returned status: " + status);
                return points;
            }

            JSONArray routes = jsonObject.getJSONArray("routes");
            if (routes.length() == 0) {
                Log.w(TAG, "No routes found in response");
                return points;
            }

            // Get the first route
            JSONObject route = routes.getJSONObject(0);
            JSONArray legs = route.getJSONArray("legs");

            // Process each leg of the route
            for (int i = 0; i < legs.length(); i++) {
                JSONObject leg = legs.getJSONObject(i);
                JSONArray steps = leg.getJSONArray("steps");

                // Process each step
                for (int j = 0; j < steps.length(); j++) {
                    JSONObject step = steps.getJSONObject(j);

                    // Get the start location of each step
                    if (j == 0 || points.isEmpty()) {
                        JSONObject startLocation = step.getJSONObject("start_location");
                        points.add(new LatLng(
                                startLocation.getDouble("lat"),
                                startLocation.getDouble("lng")
                        ));
                    }

                    // Decode the polyline for this step
                    JSONObject polyline = step.getJSONObject("polyline");
                    List<LatLng> decodedPoints = decodePoly(polyline.getString("points"));
                    points.addAll(decodedPoints);

                    // Add end location if it's the last step
                    if (j == steps.length() - 1) {
                        JSONObject endLocation = step.getJSONObject("end_location");
                        points.add(new LatLng(
                                endLocation.getDouble("lat"),
                                endLocation.getDouble("lng")
                        ));
                    }
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error parsing JSON response", e);
        }

        return points;
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        try {
            while (index < len) {
                int b, shift = 0, result = 0;
                do {
                    b = encoded.charAt(index++) - 63;
                    result |= (b & 0x1f) << shift;
                    shift += 5;
                } while (b >= 0x20);
                int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
                lat += dlat;

                shift = 0;
                result = 0;
                do {
                    b = encoded.charAt(index++) - 63;
                    result |= (b & 0x1f) << shift;
                    shift += 5;
                } while (b >= 0x20);
                int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
                lng += dlng;

                LatLng p = new LatLng((lat / 1E5), (lng / 1E5));
                poly.add(p);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error decoding polyline", e);
        }

        return poly;
    }
}