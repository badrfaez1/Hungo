package com.example.hello;


import com.google.android.gms.maps.model.LatLng;

public class FoodBank {
    private String name;
    private float rating;
    private String address;
    private String phoneNumber;
    private LatLng location;
    private String email;
     private String id;

    // Update constructor to include id
    public FoodBank(String id, String name, float rating, String phoneNumber, String email, String address, LatLng location) {
        this.id = id;
        this.name = name;
        this.rating = rating;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.address = address;
        this.location = location;
    }

    public FoodBank(String name, float rating,String phoneNumber, String email, String address, LatLng location) {
        this.name = name;
        this.rating = rating;
        this.phoneNumber=phoneNumber;
        this.email=email;
        this.address = address;
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public float getRating() {
        return rating;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public LatLng getLocation() {
        return location;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}