package com.example.hello;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Filter;
import android.widget.Filterable;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class FoodBankAdapter extends RecyclerView.Adapter<FoodBankAdapter.FoodBankViewHolder> implements Filterable{
    Context context;
    ArrayList<FoodBank> foodBankList;
    ArrayList<FoodBank> foodBankListFull;
    public FoodBankAdapter(Context context, ArrayList<FoodBank> foodBankList) {
        this.context = context;
        this.foodBankList = foodBankList;
        this.foodBankListFull = new ArrayList<>(foodBankList);
    }

    public Filter getFilter() {
        return foodBankFilter;
    }

    private final Filter foodBankFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<FoodBank> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(foodBankListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (FoodBank foodBank : foodBankListFull) {
                    // Check all fields for the search term
                    if (foodBank.getName().toLowerCase().contains(filterPattern) ||
                            foodBank.getAddress().toLowerCase().contains(filterPattern) ||
                            foodBank.getPhoneNumber().toLowerCase().contains(filterPattern) ||
                            foodBank.getEmail().toLowerCase().contains(filterPattern)) {
                        filteredList.add(foodBank);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            foodBankList.clear();
            foodBankList.addAll((ArrayList) results.values);
            notifyDataSetChanged();
        }
    };
    @NonNull
    @Override

    public FoodBankViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.fragment_foodbank_card, parent, false);
        return new FoodBankViewHolder(view);
    }


    public void onBindViewHolder(@NonNull FoodBankViewHolder holder, int position) {
        FoodBank foodBank = foodBankList.get(position);

        holder.foodbank_name.setText(foodBank.getName());
        holder.phoneNumber.setText(foodBank.getPhoneNumber());
        holder.email.setText(foodBank.getEmail());
        holder.foodbank_address.setText(foodBank.getAddress());
        holder.rating_bar.setRating(foodBank.getRating());
        holder.rating_text.setText(String.format("%.1f", foodBank.getRating()));

        holder.initializeMapView();

        holder.map.getMapAsync(googleMap -> {
            LatLng location = foodBank.getLocation();
            googleMap.addMarker(new MarkerOptions()
                    .position(location)
                    .title(foodBank.getName()));
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f));
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, foodBank_Detaits.class);
            intent.putExtra("name", foodBank.getName());
            intent.putExtra("phoneNumber", foodBank.getPhoneNumber());
            intent.putExtra("email", foodBank.getEmail());
            intent.putExtra("address", foodBank.getAddress());
            intent.putExtra("rating", foodBank.getRating());
            intent.putExtra("latitude", foodBank.getLocation().latitude);
            intent.putExtra("longitude", foodBank.getLocation().longitude);
            context.startActivity(intent);
        });
    }


    @Override
    public int getItemCount() {
        return foodBankList.size();
    }

    public static class FoodBankViewHolder extends RecyclerView.ViewHolder {
        MapView map;
        TextView foodbank_address;
        TextView phoneNumber;
        TextView email;
        TextView rating_text;
        TextView foodbank_name;
        RatingBar rating_bar;
        GoogleMap googleMap;

        public FoodBankViewHolder(@NonNull View itemView) {
            super(itemView);
            map = itemView.findViewById(R.id.map_view);
            foodbank_address = itemView.findViewById(R.id.foodbank_address);
            phoneNumber = itemView.findViewById(R.id.foodbank_contact);
            email = itemView.findViewById(R.id.foodbank_email);
            rating_text = itemView.findViewById(R.id.rating_text);
            foodbank_name = itemView.findViewById(R.id.foodbank_name);
            rating_bar = itemView.findViewById(R.id.rating_bar);
        }

        public void initializeMapView() {
            if (map != null) {
                map.onCreate(null);
                map.onResume();
                map.getMapAsync(map -> {
                    googleMap = map;
                    googleMap.getUiSettings().setScrollGesturesEnabled(false);
                });
            }
        }
    }
}