package com.example.hello;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;  // Changed to androidx.appcompat.widget.Toolbar
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class Food_Details extends BaseActivity {
    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private String foodId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_food_details);  // Changed to match BaseActivity

        // Initialize Firebase
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // Setup toolbar

        // Get views and set data
        setupViews();
    }

    private void setupViews() {
//        ImageView foodImage = findViewById(R.id.foodDetailImage);
        TextView foodName = findViewById(R.id.foodDetailName);
        TextView description = findViewById(R.id.foodDetailDescription);
        TextView expiry = findViewById(R.id.foodDetailExpiry);
        TextView contact = findViewById(R.id.foodDetailContact);
        Button deleteButton = findViewById(R.id.deleteButton);

        // Get data from intent
        foodId = getIntent().getStringExtra("food_id");
        String name = getIntent().getStringExtra("food_name");
        String desc = getIntent().getStringExtra("food_description");
        String expiryDate = getIntent().getStringExtra("food_expiry");
        String contactNum = getIntent().getStringExtra("food_contact");
        String userId = getIntent().getStringExtra("user_id");

        // Set data to views
//        foodImage.setImageResource(R.drawable.foodbankimage);
        foodName.setText(name);
        description.setText(desc);
        expiry.setText("Expiry Date: " + expiryDate);
        contact.setText("Contact: " + contactNum);

        // Show delete button only for the food item owner
        if (auth.getCurrentUser() != null &&
                userId != null &&
                auth.getCurrentUser().getUid().equals(userId)) {
            deleteButton.setVisibility(View.VISIBLE);
            deleteButton.setOnClickListener(v -> deleteFood());
        } else {
            deleteButton.setVisibility(View.GONE);
        }
    }

    private void deleteFood() {
        if (foodId != null) {
            db.collection("shared_foods").document(foodId)
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Food item deleted successfully",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this,
                            "Error deleting food item", Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}