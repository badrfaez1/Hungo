package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.GeoPoint;
import java.util.ArrayList;

public class HomeActivity extends BaseActivity {

    private ArrayList<FoodBank> foodBankList;
    private FoodBankAdapter adapter;
    private TextView welcome;

    private final ActivityResultLauncher<Intent> addFoodBankLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    String name = result.getData().getStringExtra("name");
                    String address = result.getData().getStringExtra("address");
                    String phoneNumber = result.getData().getStringExtra("phoneNumber");
                    String email = result.getData().getStringExtra("email");
                    float rating = result.getData().getFloatExtra("rating", 0);
                    double latitude = result.getData().getDoubleExtra("latitude", 0);
                    double longitude = result.getData().getDoubleExtra("longitude", 0);

                    // Add the new food bank to the list
                    FoodBank newFoodBank = new FoodBank(name, rating, phoneNumber, email, address, new LatLng(latitude, longitude));
                    foodBankList.add(newFoodBank);
                    adapter.notifyItemInserted(foodBankList.size() - 1);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_home);

        // Initialize the list and adapter
        foodBankList = new ArrayList<>();
        adapter = new FoodBankAdapter(this, foodBankList);

        welcome = findViewById(R.id.welcome_message);
        RecyclerView recyclerView = findViewById(R.id.foodbank_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        fetchAndDisplayUsername();
//        initializeDummyData();
        setupSearchFunctionality();
        initializeFAB();
    }

    private void setupSearchFunctionality() {
        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                performSearch(newText);
                return true;
            }
        });
    }

    private boolean isAddressMatch(String address, String searchTerm) {
        if (address == null) return false;

        // Split address into words
        String[] addressWords = address.toLowerCase().split("\\s+");

        // Split search term into words
        String[] searchWords = searchTerm.toLowerCase().split("\\s+");

        // Check each search word
        for (String searchWord : searchWords) {
            boolean wordFound = false;

            // Check against each address word
            for (String addressWord : addressWords) {
                // Check exact match
                if (addressWord.equals(searchWord)) {
                    wordFound = true;
                    break;
                }

                // Check if address word contains the search word as a complete part
                String[] parts = addressWord.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
                for (String part : parts) {
                    if (part.equals(searchWord)) {
                        wordFound = true;
                        break;
                    }
                }
            }

            // If any search word isn't found, return false
            if (!wordFound) return false;
        }

        return true;
    }

    private void performSearch(String searchText) {
        if (searchText == null || searchText.trim().isEmpty()) {
            loadAllFoodBanks();
            return;
        }

        String searchTerm = searchText.trim().toLowerCase();

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("foodbank")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    foodBankList.clear();

                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        // Get all the searchable fields
                        String name = document.getString("name");
                        String address = document.getString("address");
                        String email = document.getString("email");
                        String phoneNumber = document.getString("phoneNumber");

                        // Convert to lowercase for case-insensitive search
                        String nameLower = name != null ? name.toLowerCase() : "";
                        String addressLower = address != null ? address.toLowerCase() : "";
                        String emailLower = email != null ? email.toLowerCase() : "";
                        String phoneLower = phoneNumber != null ? phoneNumber.toLowerCase() : "";

                        // If any field matches the search criteria
                        if (nameLower.contains(searchTerm) ||
                                isAddressMatch(addressLower, searchTerm) ||
                                emailLower.contains(searchTerm) ||
                                phoneLower.contains(searchTerm)) {

                            // Create FoodBank object
                            String id = document.getId();
                            float rating = document.getDouble("rating") != null ?
                                    document.getDouble("rating").floatValue() : 0f;
                            GeoPoint geoPoint = document.getGeoPoint("location");
                            LatLng location = null;
                            if (geoPoint != null) {
                                location = new LatLng(geoPoint.getLatitude(), geoPoint.getLongitude());
                            }

                            FoodBank foodBank = new FoodBank(id, name, rating, phoneNumber,
                                    email, address, location);
                            foodBankList.add(foodBank);
                        }
                    }

                    if (foodBankList.isEmpty()) {
//                        Toast.makeText(HomeActivity.this,
//                                "No food banks found matching '" + searchText + "'",
//                                Toast.LENGTH_SHORT).show();
                    }

                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
//                    Toast.makeText(HomeActivity.this,
//                            "Error searching food banks: " + e.getMessage(),
//                            Toast.LENGTH_SHORT).show();
                });
    }

    private void loadAllFoodBanks() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("foodbank")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    foodBankList.clear();

                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        String id = document.getId();
                        String name = document.getString("name");
                        float rating = document.getDouble("rating") != null ?
                                document.getDouble("rating").floatValue() : 0f;
                        String phoneNumber = document.getString("phoneNumber");
                        String email = document.getString("email");
                        String address = document.getString("address");
                        GeoPoint geoPoint = document.getGeoPoint("location");
                        LatLng location = null;
                        if (geoPoint != null) {
                            location = new LatLng(geoPoint.getLatitude(), geoPoint.getLongitude());
                        }

                        FoodBank foodBank = new FoodBank(id, name, rating, phoneNumber, email, address, location);
                        foodBankList.add(foodBank);
                    }

                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(HomeActivity.this,
                            "Error loading food banks: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void fetchAndDisplayUsername() {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        if (auth.getCurrentUser() != null) {
            String userId = auth.getCurrentUser().getUid();

            db.collection("users").document(userId).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            String username = documentSnapshot.getString("username");
                            if (username != null) {
                                welcome.setText("Welcome, " + username + "!");
                            } else {
                                welcome.setText("Welcome!");
                            }
                        } else {
                            welcome.setText("Welcome!");
                            Toast.makeText(this, "User data not found!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        welcome.setText("Welcome!");
                        Toast.makeText(this, "Error fetching user: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            welcome.setText("Welcome!");
            Toast.makeText(this, "User not authenticated!", Toast.LENGTH_SHORT).show();
        }
    }
//
//    private void initializeDummyData() {
//        foodBankList.add(new FoodBank(
//                "Kein Hin Food Bank",
//                4.5f,
//                "0124450514",
//                "Kein@gmail.com",
//                "123 Jalan Kapar, Klang, Selangor",
//                new LatLng(3.0502, 101.4496)
//        ));
//
//        foodBankList.add(new FoodBank(
//                "Food Aid Foundation",
//                4.7f,
//                "0124450514",
//                "Kein@gmail.com",
//                "123 Jalan Kapar, Klang, Selangor",
//                new LatLng(3.1370, 101.6869)
//        ));
//
//        foodBankList.add(new FoodBank(
//                "MyKasih Foundation",
//                4.8f,
//                "0124450514",
//                "Kein@gmail.com",
//                "12 Persiaran Tropicana, Petaling Jaya",
//                new LatLng(3.1278, 101.5945)
//        ));
//
//        foodBankList.add(new FoodBank(
//                "Kembara Kitchen Food Bank",
//                4.6f,
//                "0124450514",
//                "Kein@gmail.com",
//                "45 Jalan Meru, Klang, Selangor",
//                new LatLng(3.0567, 101.4794)
//        ));
//
//        foodBankList.add(new FoodBank(
//                "The Lost Food Project",
//                4.9f,
//                "0124450514",
//                "Kein@gmail.com",
//                "75 Jalan Ara, Bangsar, Kuala Lumpur",
//                new LatLng(3.1311, 101.6723)
//        ));
//    }

    private void initializeFAB() {
        FloatingActionButton fabAddFoodbank = findViewById(R.id.addFoodBankButton);
        fabAddFoodbank.setOnClickListener(view -> {
            Intent intent = new Intent(this, AddFoodBank.class);
            addFoodBankLauncher.launch(intent);
        });
    }
}