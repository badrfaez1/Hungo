package com.example.hello;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.Map;

public class HungerReportFragment extends Fragment {
    // UI Components
    private TextView tvLocation, tvContact, tvDate, tvIncomeLevel, tvFamilyDetails, tvRemarks;
    private Button btnDelete;

    // Firebase Instances
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    // Variables
    private String reportID;
    private Map<String, Object> reportData;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_hungerreporting, container, false);

        // Initialize Firebase instances
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // Initialize UI components
        initializeViews(view);

        // Retrieve arguments passed to the fragment
        if (getArguments() != null) {
            reportID = getArguments().getString("DOCUMENT_ID");
            if (reportID != null) {
                fetchReportDetails();
            } else {
                Toast.makeText(getContext(), "Invalid report ID!", Toast.LENGTH_SHORT).show();
            }
        }

        return view;
    }

    /**
     * Initialize UI components.
     */
    private void initializeViews(View view) {
        tvLocation = view.findViewById(R.id.Location);
        tvContact = view.findViewById(R.id.Contact);
        tvDate = view.findViewById(R.id.Date);
        tvIncomeLevel = view.findViewById(R.id.IncomeLevel);
        tvFamilyDetails = view.findViewById(R.id.FamilyDetails);
        tvRemarks = view.findViewById(R.id.Remarks);
        btnDelete = view.findViewById(R.id.btnDelete);
        btnDelete.setVisibility(View.GONE); // Hide the delete button by default
    }

    /**
     * Fetch report details from the Firestore database.
     */
    private void fetchReportDetails() {
        db.collection("hunger_reports")
                .document(reportID)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        reportData = documentSnapshot.getData();
                        displayReportData(documentSnapshot);
                        checkDeletePermission(documentSnapshot);
                    } else {
                        Toast.makeText(getContext(), "Report not found!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Error fetching report: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    /**
     * Display report details on the UI.
     */
    private void displayReportData(DocumentSnapshot document) {
        tvLocation.setText("Location: " + getNonNullString(document.getString("location")));
        tvContact.setText("Contact: " + getNonNullString(document.getString("contactNumber")));
        tvDate.setText("Date: " + getNonNullString(document.getString("date")));
        tvIncomeLevel.setText("Income Level: " + getNonNullString(document.getString("incomeLevel")));
        tvFamilyDetails.setText("Family Members: " + getNonNullString(document.getString("familyMembers")));
        tvRemarks.setText("Remarks: " + getNonNullString(document.getString("remarks")));
    }

    /**
     * Get a non-null string value from the document.
     */
    private String getNonNullString(String value) {
        return value != null ? value : "N/A";
    }

    /**
     * Check if the current user has permission to delete the report.
     */
    private void checkDeletePermission(DocumentSnapshot document) {
        if (auth.getCurrentUser() != null) {
            String reportUserId = document.getString("userId");
            String currentUserId = auth.getCurrentUser().getUid();
            String originalReportID = document.getString("reportID"); // Check if report is already archived

            if (currentUserId.equals(reportUserId) && originalReportID == null) {
                btnDelete.setVisibility(View.VISIBLE);
                setupDeleteButton();
            } else {
                btnDelete.setVisibility(View.GONE);
            }
        }
    }

    /**
     * Set up the delete button functionality.
     */
    private void setupDeleteButton() {
        btnDelete.setOnClickListener(v -> {
            db.collection("past_reports")
                    .add(reportData)
                    .addOnSuccessListener(documentReference -> deleteOriginalReport())
                    .addOnFailureListener(e ->
                            Toast.makeText(getContext(), "Error archiving report: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        });
    }

    /**
     * Delete the original report from the active collection.
     */
    private void deleteOriginalReport() {
        db.collection("hunger_reports")
                .document(reportID)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Report deleted successfully!", Toast.LENGTH_SHORT).show();
                    if (getActivity() != null) {
                        getActivity().finish();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Error deleting report: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
