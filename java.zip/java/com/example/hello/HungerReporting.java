package com.example.hello;

public class HungerReporting {
    private String familyMembers;
    private String location;
    private String day;
    private String dateHR;
    private String incomeLevel;
    private String remarks;
    private String contactNumber;
    private String reportId;
    private String userId;

    // Main constructor that includes all fields
    public HungerReporting(String familyMembers, String location, String day, String date,
                           String incomeLevel, String remarks, String contactNumber,
                           String reportId, String userId) {
        this.familyMembers = familyMembers;
        this.location = location;
        this.day = day;
        this.dateHR = date;
        this.incomeLevel = incomeLevel;
        this.remarks = remarks;
        this.contactNumber = contactNumber;
        this.reportId = reportId;
        this.userId = userId;
    }

    // Constructor without userId
    public HungerReporting(String familyMembers, String location, String day, String date,
                           String incomeLevel, String remarks, String contactNumber,
                           String reportId) {
        this(familyMembers, location, day, date, incomeLevel, remarks, contactNumber,
                reportId, null);
    }

    // Constructor without reportId and userId
    public HungerReporting(String familyMembers, String location, String day, String date,
                           String incomeLevel, String remarks, String contactNumber) {
        this(familyMembers, location, day, date, incomeLevel, remarks, contactNumber,
                null, null);
    }

    // Getters
    public String getFamilymembers() { return familyMembers; }
    public String getLocation() { return location; }
    public String getDay() { return day; }
    public String getDateHR() { return dateHR; }
    public String getIncomeLevel() { return incomeLevel; }
    public String getRemarks() { return remarks; }
    public String getContactNumber() { return contactNumber; }
    public String getReportId() { return reportId; }
    public String getUserId() { return userId; }

    // Setters
    public void setFamilymembers(String familyMembers) { this.familyMembers = familyMembers; }
    public void setLocation(String location) { this.location = location; }
    public void setDay(String day) { this.day = day; }
    public void setDateHR(String dateHR) { this.dateHR = dateHR; }
    public void setIncomeLevel(String incomeLevel) { this.incomeLevel = incomeLevel; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public void setReportId(String reportId) { this.reportId = reportId; }
    public void setUserId(String userId) { this.userId = userId; }
}