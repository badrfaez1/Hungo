package com.example.hello;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.List;

public class HungerReportingActivity extends BaseActivity {
    private HungerReportingAdapter currentReportsAdapter;
    private HungerReportingAdapter pastReportsAdapter;
    private List<HungerReporting> currentReportsList;
    private List<HungerReporting> pastReportsList;
    private ActivityResultLauncher<Intent> addHungerReportLauncher;
    private TabLayout tabLayout;
    private RecyclerView recyclerView;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.fragment_displayhungerreporting);

        // Initialize views
        FloatingActionButton addHungerRep = findViewById(R.id.addHR);
        recyclerView = findViewById(R.id.hr_recycler_view);
        tabLayout = findViewById(R.id.tabLayout);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize lists and adapters
        currentReportsList = new ArrayList<>();
        pastReportsList = new ArrayList<>();
        currentReportsAdapter = new HungerReportingAdapter(this, currentReportsList);
        pastReportsAdapter = new HungerReportingAdapter(this, pastReportsList);

        // Set initial adapter
        recyclerView.setAdapter(currentReportsAdapter);

        // Setup tab selection listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    recyclerView.setAdapter(currentReportsAdapter);
                    loadCurrentReportsFromFirestore();
                } else {
                    recyclerView.setAdapter(pastReportsAdapter);
                    loadPastReportsFromFirestore();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        // Load initial data
        loadCurrentReportsFromFirestore();

        // Setup activity launcher
        setupActivityLauncher();

        addHungerRep.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddHungerReportActivity.class);
            addHungerReportLauncher.launch(intent);
        });
    }

    private void setupActivityLauncher() {
        addHungerReportLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadCurrentReportsFromFirestore();
                    }
                }
        );
    }

    private void loadCurrentReportsFromFirestore() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseAuth auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            db.collection("hunger_reports")
                    .addSnapshotListener((value, error) -> {
                        if (error != null) {
                            Toast.makeText(this, "Error loading reports: " + error.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (value != null) {
                            currentReportsList.clear();
                            for (DocumentSnapshot document : value.getDocuments()) {
                                HungerReporting report = createReportFromDocument(document);
                                currentReportsList.add(report);
                            }
                            currentReportsAdapter.notifyDataSetChanged();
                        }
                    });
        }
    }

    private void loadPastReportsFromFirestore() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseAuth auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            String userId = auth.getCurrentUser().getUid();
            db.collection("past_reports")
                    .whereEqualTo("userId", userId)  // Only get past reports for current user
                    .addSnapshotListener((value, error) -> {
                        if (error != null) {
                            Toast.makeText(this, "Error loading past reports: " + error.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (value != null) {
                            pastReportsList.clear();
                            for (DocumentSnapshot document : value.getDocuments()) {
                                HungerReporting report = createReportFromDocument(document);
                                pastReportsList.add(report);
                            }
                            pastReportsAdapter.notifyDataSetChanged();
                        }
                    });
        }
    }

    private HungerReporting createReportFromDocument(DocumentSnapshot document) {
        return new HungerReporting(
                document.getString("familyMembers"),
                document.getString("location"),
                document.getString("day"),
                document.getString("date"),
                document.getString("incomeLevel"),
                document.getString("remarks"),
                document.getString("contactNumber"),
                document.getId(),
                document.getString("userId")
        );
    }
}