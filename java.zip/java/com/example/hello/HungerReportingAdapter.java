package com.example.hello;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class HungerReportingAdapter extends RecyclerView.Adapter<HungerReportingAdapter.HungerReportingViewHolder> {

    private final List<HungerReporting> hungerReportingList;
    private final FirebaseFirestore db;
    private final Context context;

    public HungerReportingAdapter(Context context, List<HungerReporting> hungerReportingList) {
        this.context = context;
        this.hungerReportingList = hungerReportingList;
        this.db = FirebaseFirestore.getInstance();
        setupFirebaseListener();
    }

    private void setupFirebaseListener() {
        db.collection("hunger_reports")
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        return;
                    }
                    if (value != null) {
                        hungerReportingList.clear();
                        for (QueryDocumentSnapshot document : value) {
                            // Add explicit logging for debugging
                            String contactNumber = document.getString("contactNumber");
                            System.out.println("Retrieved contact number: " + contactNumber);  // Debug log

                            HungerReporting report = new HungerReporting(
                                    document.getString("familyMembers"),
                                    document.getString("location"),
                                    document.getString("day"),
                                    document.getString("date"),
                                    document.getString("incomeLevel"),
                                    document.getString("remarks"),
                                    contactNumber  // Pass the contact number directly
                            );
                            hungerReportingList.add(report);
                        }
                        notifyDataSetChanged();
                    }
                });
    }

    @NonNull
    @Override
    public HungerReportingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_hungerreporting, parent, false);
        return new HungerReportingViewHolder(view);
    }



    // In HungerReportingAdapter.java, modify the onBindViewHolder method:
    @Override
    public void onBindViewHolder(@NonNull HungerReportingViewHolder holder, int position) {
        HungerReporting report = hungerReportingList.get(position);

        holder.tvFamilyMembers.setText("Family Members: " + report.getFamilymembers());
        holder.tvLocation.setText("Location: " + report.getLocation());
//        holder.tvDay.setText("Day: " + report.getDay());
        holder.tvDate.setText("Date: " + report.getDateHR());
        holder.tvIncomeLevel.setText("Income Level: " + report.getIncomeLevel());
        holder.tvRemarks.setText("Remarks: " + report.getRemarks());
        holder.tvContactNumber.setText("Contact: " +
                (report.getContactNumber() != null ? report.getContactNumber() : "N/A"));

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ReportDetailsActivity.class);
            // Add the document ID to the intent
            intent.putExtra("DOCUMENT_ID", report.getReportId());
            intent.putExtra("LOCATION", report.getLocation());
            intent.putExtra("CONTACT", report.getContactNumber() != null ?
                    report.getContactNumber() : "N/A");
            intent.putExtra("DATE", report.getDateHR());
            intent.putExtra("INCOME_LEVEL", report.getIncomeLevel());
            intent.putExtra("REMARKS", report.getRemarks());
            intent.putExtra("FAMILY_MEMBERS", report.getFamilymembers());
            intent.putExtra("DAY", report.getDay());
            context.startActivity(intent);
        });
    }


    @Override
    public int getItemCount() {
        return hungerReportingList.size();
    }

    public static class HungerReportingViewHolder extends RecyclerView.ViewHolder {
        TextView tvFamilyMembers, tvLocation, tvDay, tvDate, tvIncomeLevel, tvRemarks, tvContactNumber;

        public HungerReportingViewHolder(@NonNull View itemView) {
            super(itemView);
            tvFamilyMembers = itemView.findViewById(R.id.FamilyDetails);
            tvLocation = itemView.findViewById(R.id.Location);

            tvDate = itemView.findViewById(R.id.Date);
            tvIncomeLevel = itemView.findViewById(R.id.IncomeLevel);
            tvRemarks = itemView.findViewById(R.id.Remarks);
            tvContactNumber = itemView.findViewById(R.id.Contact);
        }
    }
}
