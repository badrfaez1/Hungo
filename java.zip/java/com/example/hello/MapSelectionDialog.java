package com.example.hello;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import android.view.WindowManager;
import android.app.Dialog;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.core.view.ViewCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.MapsInitializer;

import java.util.concurrent.atomic.AtomicBoolean;

public class MapSelectionDialog extends DialogFragment implements OnMapReadyCallback {
    private MapView mapView;
    private GoogleMap googleMap;
    private ImageButton closeButton;
    private Button confirmButton;
    private OnLocationSelectedListener locationSelectedListener;
    private LatLng selectedLocation;
    private boolean isMapReady = false;
    private static final float DEFAULT_ZOOM = 10f;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean isMapClickEnabled = new AtomicBoolean(true);

    // Cache Malaysia bounds to avoid object creation
    private static final LatLngBounds MALAYSIA_BOUNDS = new LatLngBounds(
            new LatLng(0.8553, 98.9360),  // SW bounds
            new LatLng(7.3527, 119.2690)  // NE bounds
    );
    private static final LatLng DEFAULT_POSITION = new LatLng(3.1390, 101.6869);

    // Interface for location selection callback
    public interface OnLocationSelectedListener {
        void onLocationSelected(LatLng location);
    }

    public void setOnLocationSelectedListener(OnLocationSelectedListener listener) {
        this.locationSelectedListener = listener;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_map_selection_dialog, container, false);

        // Enable hardware acceleration
        ViewCompat.setLayerType(view, View.LAYER_TYPE_HARDWARE, null);

        // Initialize views and map
        initializeViews(view);
        setupMap(savedInstanceState);

        return view;
    }

    private void initializeViews(View view) {
        mapView = view.findViewById(R.id.map_view_dialog);
        closeButton = view.findViewById(R.id.btn_close);
        confirmButton = view.findViewById(R.id.btn_confirm);

        // Set up click listeners with debounce protection
        closeButton.setOnClickListener(v -> {
            if (isMapClickEnabled.get()) {
                isMapClickEnabled.set(false);
                dismiss();
                mainHandler.postDelayed(() -> isMapClickEnabled.set(true), 300);
            }
        });

        confirmButton.setOnClickListener(v -> {
            if (isMapClickEnabled.get()) {
                isMapClickEnabled.set(false);
                handleConfirmClick();
                mainHandler.postDelayed(() -> isMapClickEnabled.set(true), 300);
            }
        });
    }

    private void setupMap(Bundle savedInstanceState) {
        try {
            MapsInitializer.initialize(requireContext());
            mapView.onCreate(savedInstanceState);
            mapView.getMapAsync(this);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error initializing map", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleConfirmClick() {
        if (selectedLocation != null && locationSelectedListener != null) {
            locationSelectedListener.onLocationSelected(selectedLocation);
            dismiss();
        } else {
            Toast.makeText(getContext(), "Please select a location!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        isMapReady = true;

        // Configure map settings
        configureMap();

        // Set up map click listener with throttling
        setupMapClickListener();
    }

    private void configureMap() {
        if (googleMap != null) {
            // Set initial camera position
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(DEFAULT_POSITION, DEFAULT_ZOOM));

            // Configure bounds and zoom levels
            googleMap.setLatLngBoundsForCameraTarget(MALAYSIA_BOUNDS);
            googleMap.setMinZoomPreference(5);  // Show all of Malaysia
            googleMap.setMaxZoomPreference(20); // Maximum street level detail

            // Optimize performance
            googleMap.getUiSettings().setRotateGesturesEnabled(false);
            googleMap.getUiSettings().setTiltGesturesEnabled(false);
            googleMap.getUiSettings().setCompassEnabled(false);
            googleMap.getUiSettings().setIndoorLevelPickerEnabled(false);

            // Enable essential controls
            googleMap.getUiSettings().setZoomControlsEnabled(true);
            googleMap.getUiSettings().setMapToolbarEnabled(false);
        }
    }

    private void setupMapClickListener() {
        if (googleMap != null) {
            googleMap.setOnMapClickListener(latLng -> {
                if (isMapReady && isMapClickEnabled.get()) {
                    isMapClickEnabled.set(false);
                    updateSelectedLocation(latLng);
                    mainHandler.postDelayed(() -> isMapClickEnabled.set(true), 300);
                }
            });
        }
    }

    private void updateSelectedLocation(LatLng latLng) {
        googleMap.clear();
        googleMap.addMarker(new MarkerOptions()
                .position(latLng)
                .draggable(false));
        selectedLocation = latLng;
        confirmButton.setEnabled(true);
    }

    // Lifecycle methods with proper cleanup
    @Override
    public void onStart() {
        super.onStart();
        if (mapView != null) {
            mapView.onStart();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mapView != null) {
            mapView.onResume();
        }
    }

    @Override
    public void onPause() {
        if (mapView != null) {
            mapView.onPause();
        }
        super.onPause();
    }

    @Override
    public void onStop() {
        if (mapView != null) {
            mapView.onStop();
        }
        super.onStop();
    }

    @Override
    public void onDestroy() {
        if (mapView != null) {
            mapView.onDestroy();
        }
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (mapView != null) {
            mapView.onLowMemory();
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mapView != null) {
            mapView.onSaveInstanceState(outState);
        }
    }
}