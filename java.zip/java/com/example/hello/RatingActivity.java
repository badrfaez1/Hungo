package com.example.hello;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

public class RatingActivity extends BaseActivity {

    private final HashMap<Integer, Integer> ratingCounts = new HashMap<>();
    private int totalRatings = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_rating);
        getSupportActionBar().hide();

        // Initialize rating counts
        for (int i = 1; i <= 5; i++) {
            ratingCounts.put(i, 0);
        }

        // Initialize UI components
        RatingBar ratingBar = findViewById(R.id.ratingBar);
        ProgressBar progress5 = findViewById(R.id.progressBar5);
        ProgressBar progress4 = findViewById(R.id.progressBar4);
        ProgressBar progress3 = findViewById(R.id.progressBar3);
        ProgressBar progress2 = findViewById(R.id.progressBar2);
        ProgressBar progress1 = findViewById(R.id.progressBar1);

        // Setup RatingBar listener
        setupRatingBar(ratingBar, progress5, progress4, progress3, progress2, progress1);
        Button submit = findViewById(R.id.submitButton);
        Button experience = findViewById(R.id.experienceButton);


        experience.setOnClickListener(v -> {
            Intent intent = new Intent(RatingActivity.this, ReviewActivity.class);
            startActivity(intent);
        });

        // Set a click listener for the submit button
        submit.setOnClickListener(v -> {
            // Get the current rating


            // Proceed to the next activity if the rating is provided
            Intent intent = new Intent(RatingActivity.this, HomeActivity.class);
            startActivity(intent);

            // Show a thank-you Toast
            Toast.makeText(
                    RatingActivity.this,
                    "Thank you for your Rating!",
                    Toast.LENGTH_SHORT
            ).show();

        });



    }

    private void setupRatingBar(RatingBar ratingBar, ProgressBar... progressBars) {
        ratingBar.setOnRatingBarChangeListener((ratingBar1, rating, fromUser) -> {
            if (fromUser) {
                int ratingValue = (int) rating;
                updateRating(ratingValue);

                // Update progress bars
                updateProgressBars(progressBars);
            }
        });
    }

    private void updateRating(int rating) {
        // Increment the selected rating count
        int currentCount = ratingCounts.getOrDefault(rating, 0);
        ratingCounts.put(rating, currentCount + 1);

        // Increment total ratings
        totalRatings++;
    }

    private void updateProgressBars(ProgressBar... progressBars) {
        for (int i = 0; i < progressBars.length; i++) {
            int count = ratingCounts.getOrDefault(5 - i, 0); // Get ratings for 5, 4, 3, etc.
            int progress = totalRatings > 0 ? (int) ((count / (float) totalRatings) * 100) : 0;
            progressBars[i].setProgress(progress);
        }
    }
}