package com.example.hello;

public class Report {
    private String location;
    private String contact;
    private String date;
    private String hungerStatus;
    private String age;
    private String incomeLevel;
    private String familyDetails;
    private String remarks;
    public  String getContactNumber(){
        return contact;
    }
    // Constructor
    public Report(String location, String contact, String date, String hungerStatus,
                  String age, String incomeLevel, String familyDetails, String remarks) {
        this.location = location;
        this.contact = contact;
        this.date = date;
        this.hungerStatus = hungerStatus;
        this.age = age;
        this.incomeLevel = incomeLevel;
        this.familyDetails = familyDetails;
        this.remarks = remarks;
    }

    // Empty constructor for Firebase
    public Report() {
    }

    // Getters and Setters
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHungerStatus() {
        return hungerStatus;
    }

    public void setHungerStatus(String hungerStatus) {
        this.hungerStatus = hungerStatus;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getIncomeLevel() {
        return incomeLevel;
    }

    public void setIncomeLevel(String incomeLevel) {
        this.incomeLevel = incomeLevel;
    }

    public String getFamilyDetails() {
        return familyDetails;
    }

    public void setFamilyDetails(String familyDetails) {
        this.familyDetails = familyDetails;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    // toString method for debugging
    @Override
    public String toString() {
        return "Report{" +
                "location='" + location + '\'' +
                ", contact='" + contact + '\'' +
                ", date='" + date + '\'' +
                ", hungerStatus='" + hungerStatus + '\'' +
                ", age='" + age + '\'' +
                ", incomeLevel='" + incomeLevel + '\'' +
                ", familyDetails='" + familyDetails + '\'' +
                ", remarks='" + remarks + '\'' +
                '}';
    }
}