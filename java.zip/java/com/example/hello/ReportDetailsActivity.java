package com.example.hello;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ReportDetailsActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_details);

        String reportID = getIntent().getStringExtra("DOCUMENT_ID");
        if (reportID != null) {
            HungerReportFragment fragment = new HungerReportFragment();
            Bundle args = new Bundle();
            args.putString("DOCUMENT_ID", reportID);
            fragment.setArguments(args);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainerView, fragment)
                    .commit();
        }else {

                HungerReportFragment fragment = new HungerReportFragment();
                Bundle args = new Bundle();
            args.putString("DOCUMENT_ID", null);
                fragment.setArguments(args);

                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, fragment)
                        .commit();
            }
        }
    }

