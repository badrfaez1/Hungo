package com.example.hello;

public class Resources extends Report {
    private String ArticleName;
    private String BriefDesc;
    private String URL;

    public Resources(String articleName,String BriefDesc,String URL) {
        this.ArticleName = articleName;
        this.BriefDesc= BriefDesc;
        this.URL=URL;
    }

    public String getArticleName() {
        return this.ArticleName;
    }

    public String getBriefDesc() {
        return BriefDesc;
    }

    public String getURL() {
        return URL;
    }
}

