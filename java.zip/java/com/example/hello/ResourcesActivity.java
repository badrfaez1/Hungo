package com.example.hello;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResourcesActivity extends BaseActivity {

    private ResourcesAdapter adapter;
    private List<Resources> ResourceList;
    private ActivityResultLauncher<Intent> addResourceLauncher;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.fragment_displayresources);
        FloatingActionButton addResource = findViewById(R.id.addResource);
        RecyclerView recyclerView = findViewById(R.id.resource_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample data for testing
        ResourceList = new ArrayList<>();
        ResourceList.add(new Resources("Lack of Food in Africa!", "around 30% of population suffering alot.", "www.foodhunger.com"));
        adapter = new ResourcesAdapter(ResourceList);
        recyclerView.setAdapter(adapter);

        // Initialize ActivityResultLauncher
        addResourceLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        String articlename = data.getStringExtra("Article Name");
                        String briefdesc = data.getStringExtra("Brief Description");
                        String url = data.getStringExtra("URL");

                        Resources newResource = new Resources(
                                articlename, briefdesc, url
                        );
                        ResourceList.add(newResource);
                        saveResourceToFirestore(newResource);
                        adapter.notifyDataSetChanged();
                    }
                });

        addResource.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddResourcesActivity.class);
            addResourceLauncher.launch(intent); // Open form activity
        });
    }

    private void saveResourceToFirestore(Resources newResource) {
        FirebaseAuth auth = FirebaseAuth.getInstance();

        // Check if the user is authenticated
        if (auth.getCurrentUser() != null) {
            String userId = auth.getCurrentUser().getUid();
            String userEmail = auth.getCurrentUser().getEmail();

            // Create a map to hold resource data
            Map<String, Object> resourceMap = new HashMap<>();
            resourceMap.put("articleName", newResource.getArticleName());
            resourceMap.put("briefDescription", newResource.getBriefDesc());
            resourceMap.put("url", newResource.getURL());
            resourceMap.put("userId", userId);
            resourceMap.put("userEmail", userEmail);

            // Add resource to Firestore under the resources collection
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("resources")
                    .add(resourceMap)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(this, "Resource added successfully!", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error adding resource: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(this, "User not authenticated!", Toast.LENGTH_SHORT).show();
        }
    }

}


