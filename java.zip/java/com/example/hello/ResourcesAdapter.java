package com.example.hello;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ResourcesAdapter extends RecyclerView.Adapter<ResourcesAdapter.ResourceViewHolder> {

    private final List<Resources> ResourceList;

    public ResourcesAdapter(List<Resources> ResourceList) {
        this.ResourceList = ResourceList;
    }

    @NonNull
    @Override
    public ResourceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_resources, parent, false);
        return new ResourceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ResourceViewHolder holder, int position) {
        Resources resource = ResourceList.get(position);

        holder.tvArticleName.setText("Article Name: " + resource.getArticleName());
        holder.tvBriefDescription.setText("Brief Description: " + resource.getBriefDesc());
        holder.tvURL.setText("URL: " + resource.getURL());

        // Open a browser when the URL is clicked
        holder.tvURL.setOnClickListener(v -> {
            String url = resource.getURL();
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "http://" + url;
            }
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            holder.itemView.getContext().startActivity(browserIntent);
        });


    }

    @Override
    public int getItemCount() {
        return ResourceList.size();
    }

    public static class ResourceViewHolder extends RecyclerView.ViewHolder {
        TextView tvArticleName, tvBriefDescription, tvURL;

        public ResourceViewHolder(@NonNull View itemView) {
            super(itemView);
            tvArticleName = itemView.findViewById(R.id.ArticleName);
            tvBriefDescription = itemView.findViewById(R.id.ArticleBriefDesc);
            tvURL = itemView.findViewById(R.id.ArticleURL);
        }
    }
}
