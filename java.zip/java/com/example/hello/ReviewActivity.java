package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ReviewActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setActivityContent(R.layout.activity_review);

        Button submit = findViewById(R.id.submitButton);

        EditText reviewEditText = findViewById(R.id.reviewEditText);

        // Set a click listener for the submit button
        submit.setOnClickListener(v -> {
 // Get the current rating


                // Proceed to the next activity if the rating is provided
                Intent intent = new Intent(ReviewActivity.this, HomeActivity.class);
                startActivity(intent);

                // Show a thank-you Toast
                Toast.makeText(
                        ReviewActivity.this,
                        "Thank you for your review!",
                        Toast.LENGTH_SHORT
                ).show();

        });
    }
}
