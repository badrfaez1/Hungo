package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SettingsAccount extends BaseActivity {

    private TextView textFullName;
    private TextView textUserName;
    private TextView textEmail;
    private Button changePasswordButton;

    private FirebaseUser currentUser;
    private FirebaseFirestore firestore;
    private DocumentReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_accountsettings);

        // Initialize Firebase components
        firestore = FirebaseFirestore.getInstance();
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        // Get a reference to the user's document in Firestore
        if (currentUser != null) {
            userRef = firestore.collection("users").document(currentUser.getUid());
        }

        // Initialize UI elements
        textFullName = findViewById(R.id.EditFullname);
        textUserName = findViewById(R.id.EditUsername);
        textEmail = findViewById(R.id.EditEmail);
        changePasswordButton = findViewById(R.id.change_password);

        // Display current user data when the activity starts
        if (currentUser != null) {
            // Email is fetched from Firebase Authentication, it's not editable
            textEmail.setText(currentUser.getEmail());

            // Fetch user details from Firestore
            userRef.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        String fullName = document.getString("fullName");
                        String username = document.getString("username");

                        // Populate the TextViews with the existing data
                        textFullName.setText(fullName);
                        textUserName.setText(username);
                    }
                }
            });
        }

        changePasswordButton.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsAccount.this, ChangePasswordActivity.class);
            startActivity(intent);
        });
    }
}

