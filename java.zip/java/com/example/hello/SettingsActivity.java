package com.example.hello;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.widget.ImageView;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class SettingsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_settings);

        // Initialize
        Button accountButton = findViewById(R.id.accountButton);
        Button helpSupportButton = findViewById(R.id.helpButton);
        Button aboutButton = findViewById(R.id.aboutButton);

        // Set OnClickListeners for Buttons
        accountButton.setOnClickListener(v -> navigateTo(SettingsAccount.class));
        helpSupportButton.setOnClickListener(v -> navigateToHelpSupport());
        aboutButton.setOnClickListener(v -> navigateToAboutApp());

        // Optional: You can set OnClickListeners for the ImageViews if needed
        accountButton.setOnClickListener(v -> {
            // You can implement any actions you want when the profile icon is clicked

        Intent intent = new Intent(SettingsActivity.this, SettingsAccount.class);
        startActivity(intent);

        });

        helpSupportButton.setOnClickListener(v -> navigateToHelpSupport());
        aboutButton.setOnClickListener(v -> navigateToAboutApp());
    }

    // Helper method to navigate to the AccountActivity
    private void navigateTo(Class<?> targetActivity) {
        Intent intent = new Intent(SettingsActivity.this, targetActivity);
        startActivity(intent);
    }

    // Navigate to Help and Support Screen
    private void navigateToHelpSupport() {
        setActivityContent(R.layout.activity_helpsupport);  // Assuming your XML is activity_help_support.xml
    }

    // Navigate to About App Screen
    private void navigateToAboutApp() {
        setActivityContent(R.layout.activity_about_app);  // Assuming your XML is activity_about_app.xml
    }
}
