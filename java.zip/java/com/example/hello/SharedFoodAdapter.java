package com.example.hello;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class SharedFoodAdapter extends RecyclerView.Adapter<SharedFoodAdapter.CommViewHolder> {

    private final List<SharedFoodItem> shareFoodList;
    private final FirebaseFirestore db;
    private final FirebaseAuth auth;

    public SharedFoodAdapter(List<SharedFoodItem> shareFoodList) {
        this.shareFoodList = shareFoodList;
        this.db = FirebaseFirestore.getInstance();
        this.auth = FirebaseAuth.getInstance();
    }

    @NonNull
    @Override
    public CommViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_shared_food, parent, false);
        return new CommViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CommViewHolder holder, int position) {
        SharedFoodItem food = shareFoodList.get(position);
        Context context = holder.itemView.getContext();

        // Set basic food information
        holder.tvFoodName.setText(food.getFoodName());
        holder.tvFoodDescrption.setText(food.getDescription());
        holder.tvExpiryDate.setText("Expiry: " + food.getExpiryDate());
        holder.tvContactNumber.setText("Contact: " + food.getContactNumber());
        holder.cardImage.setImageResource(R.drawable.foodbankimage);

        // Set click listener to start Food_Details activity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, Food_Details.class);
            intent.putExtra("food_id", food.getId());
            intent.putExtra("food_name", food.getFoodName());
            intent.putExtra("food_description", food.getDescription());
            intent.putExtra("food_expiry", food.getExpiryDate());
            intent.putExtra("food_contact", food.getContactNumber());
            intent.putExtra("user_id", food.getUserId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return shareFoodList.size();
    }

    public static class CommViewHolder extends RecyclerView.ViewHolder {
        TextView tvFoodName, tvFoodDescrption, tvExpiryDate, tvContactNumber;
        ImageView cardImage;

        public CommViewHolder(@NonNull View itemView) {
            super(itemView);
            tvFoodName = itemView.findViewById(R.id.foodNameText);
            tvFoodDescrption = itemView.findViewById(R.id.descriptionText);
            tvExpiryDate = itemView.findViewById(R.id.expiryDateText);
            tvContactNumber = itemView.findViewById(R.id.ContactNumFood);
            cardImage = itemView.findViewById(R.id.foodImage);
        }
    }
}
