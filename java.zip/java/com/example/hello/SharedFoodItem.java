package com.example.hello;

import androidx.annotation.NonNull;
import com.google.firebase.firestore.ServerTimestamp;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

public class SharedFoodItem implements Serializable {
    private String foodName;      // Name of the food item
    private String description;   // Description of the food item
    private String expiryDate;    // Expiry date of the food
    private String contactNumber;
    private String foodDescription;
    private String id;

    private String userId; // To check if user can delete

    public SharedFoodItem(String id, String foodName, String description, String expiryDate, String contactNumber, String userId) {
        this.id = id;
        this.foodName = foodName;
        this.description = description;
        this.expiryDate = expiryDate;
        this.contactNumber = contactNumber;
        this.userId = userId;
    }

    // Add getters
    public String getId() { return id; }
    public String getUserId() { return userId; }

    private boolean isAvailable;  // Whether the item is still available
    @ServerTimestamp
    private Date timestamp;       // Server timestamp when created

    // Required empty constructor for Firestore
    public SharedFoodItem() {}

    // Constructor for new food items
    public SharedFoodItem(String foodName, String foodDescription, String expiryDate, String contactNumber) {

        this.foodName = foodName;
        this.foodDescription=foodDescription;
        this.expiryDate = expiryDate;
        this.contactNumber = contactNumber;

    }

    // Constructor with all fields
    public SharedFoodItem(String userName, String foodName, String expiryDate,
                          String imageUrl, String description) {
        this(userName, foodName, expiryDate, imageUrl);
        this.description = description;
    }


    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getDescription() {
        return foodDescription;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public void setId(String id) {
        this.id = id;
    }
    public  String getFoodDescription(){
        return foodDescription;
    }
    public void setFoodDescription(String foodDescription){
        this.foodDescription=foodDescription;
    }


    public void setUserId(String userId) {
        this.userId=userId;
    }





}



