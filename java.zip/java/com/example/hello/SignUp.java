package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import android.widget.Button;
import android.widget.EditText;

public class SignUp extends AppCompatActivity {

    private EditText emailInput, usernameInput, fullNameInput, passwordInput, confirmpasswordInput;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        emailInput= findViewById(R.id.signup_email);
        usernameInput = findViewById(R.id.signup_username);
        fullNameInput = findViewById(R.id.signup_name);
        passwordInput = findViewById(R.id.signup_password);
        confirmpasswordInput = findViewById(R.id.signup_confirm);
        Button signupButton = findViewById(R.id.signup_button);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        signupButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString();
            String username = usernameInput.getText().toString();
            String fullName = fullNameInput.getText().toString();
            String password = passwordInput.getText().toString();
            String confirmpassword = confirmpasswordInput.getText().toString();

            if (!email.isEmpty() && !username.isEmpty() && !fullName.isEmpty() && !password.isEmpty() && password.equals(confirmpassword)) {
                createAccount(email, username, fullName, password);
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createAccount(String email, String username, String fullName, String password) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = auth.getCurrentUser();
                        if (user != null) {
                            saveUserToFirestore(user.getUid(), email, username, fullName);
                        }
                    } else {
                        if (task.getException() != null) {
                            String errorMessage;
                            try {
                                throw task.getException();
                            } catch (FirebaseAuthWeakPasswordException e) {
                                errorMessage = "Weak password! Password should be at least 6 characters.";
                            } catch (FirebaseAuthInvalidCredentialsException e) {
                                errorMessage = "Invalid email format!";
                            } catch (FirebaseAuthUserCollisionException e) {
                                errorMessage = "Email is already in use.";
                            } catch (Exception e) {
                                errorMessage = "Signup failed: " + e.getMessage();
                            }
                            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
                    }}
                });
    }

    private void saveUserToFirestore(String uid, String email, String username, String fullName) {
        Map<String, Object> userMap = new HashMap<>();
        userMap.put("email", email);
        userMap.put("username", username);
        userMap.put("fullName", fullName);

        db.collection("users").document(uid)
                .set(userMap)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Signup successful! Please log in.", Toast.LENGTH_SHORT).show();
                    // Redirect to LoginActivity
                    Intent intent = new Intent(SignUp.this, Login.class);
                    startActivity(intent);
                    finish(); // Prevent back navigation to signup screen
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error saving user: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    }






