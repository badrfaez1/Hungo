package com.example.hello;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomePage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // Find the buttons by their ID
        Button loginButton = findViewById(R.id.login_buttonWelcome);
        Button signupButton = findViewById(R.id.signup_buttonWelcome);
        TextView aboutAppButton = findViewById(R.id.aboutapplink);

        // Set onClickListener for AboutApp TextView
        aboutAppButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Navigate to AboutApp activity
                Intent intent = new Intent(WelcomePage.this, AboutApp.class);
                startActivity(intent);
            }
        });

        // Set onClickListener for Login Button
        loginButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Navigate to LoginActivity
                Intent intent = new Intent(WelcomePage.this, Login.class);
                startActivity(intent);
            }
        });

        // Set onClickListener for Signup Button
        signupButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Navigate to SignUp activity
                Intent intent = new Intent(WelcomePage.this, SignUp.class);
                startActivity(intent);
            }
        });
    }
}
