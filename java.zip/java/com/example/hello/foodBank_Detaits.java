package com.example.hello;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.Task;

public class foodBank_Detaits extends BaseActivity implements OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final String[] REQUIRED_PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

    private FusedLocationProviderClient fusedLocationClient;
    private GoogleMap googleMap;
    private MapView mapView;
    private boolean locationPermissionGranted = false;
    private LatLng foodBankLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setActivityContent(R.layout.activity_food_bank_details);

        // Initialize views and data
        initializeViews();

        // Initialize location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Store food bank location
        double latitude = getIntent().getDoubleExtra("latitude", 0);
        double longitude = getIntent().getDoubleExtra("longitude", 0);
        foodBankLocation = new LatLng(latitude, longitude);

        // Initialize MapView
        mapView = findViewById(R.id.map_view);
        mapView.onCreate(savedInstanceState);

        // Check permissions before initializing map
        checkPermissions();
    }

    private void initializeViews() {
        TextView nameText = findViewById(R.id.name_text);
        TextView addressText = findViewById(R.id.address_text);
        TextView ratingValueText = findViewById(R.id.rating_value_text);
        RatingBar ratingBar = findViewById(R.id.detail_rating_bar);
        Button rateReviewButton = findViewById(R.id.rate_review_button);
        TextView phoneNumberText = findViewById(R.id.contact_text);
        TextView emailText = findViewById(R.id.email_text);

        // Set data from intent
        nameText.setText(getIntent().getStringExtra("name"));
        addressText.setText(getIntent().getStringExtra("address"));
        float rating = getIntent().getFloatExtra("rating", 0);
        ratingValueText.setText(String.format("%.1f", rating));
        ratingBar.setRating(rating);
        phoneNumberText.setText(getIntent().getStringExtra("phoneNumber"));
        emailText.setText(getIntent().getStringExtra("email"));

        rateReviewButton.setOnClickListener(view -> {
            Intent intent = new Intent(foodBank_Detaits.this, RatingActivity.class);
            startActivity(intent);
        });
    }

    private void checkPermissions() {
        boolean allPermissionsGranted = true;
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break;
            }
        }

        if (allPermissionsGranted) {
            locationPermissionGranted = true;
            initializeMap();
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void initializeMap() {
        mapView.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.googleMap = googleMap;

        if (locationPermissionGranted) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                googleMap.setMyLocationEnabled(true);
                getCurrentLocationAndDrawRoute();
            }
        }
    }

    private void getCurrentLocationAndDrawRoute() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());

                    // Add markers
                    googleMap.addMarker(new MarkerOptions()
                            .position(userLocation)
                            .title("Your Location"));

                    googleMap.addMarker(new MarkerOptions()
                            .position(foodBankLocation)
                            .title("Food Bank"));

                    // Draw route
                    String url = buildDirectionsUrl(userLocation, foodBankLocation);
                    new FetchDirectionsTask(this, googleMap, userLocation, foodBankLocation).execute(url);

                    // Move camera to show both points
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    builder.include(userLocation);
                    builder.include(foodBankLocation);
                    LatLngBounds bounds = builder.build();

                    googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100));
                }
            });
        }
    }

    private String buildDirectionsUrl(LatLng origin, LatLng destination) {
        return "https://maps.googleapis.com/maps/api/directions/json?"
                + "origin=" + origin.latitude + "," + origin.longitude
                + "&destination=" + destination.latitude + "," + destination.longitude
                + "&key=" + getString(R.string.google_api_key);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {
                boolean allPermissionsGranted = true;
                for (int result : grantResults) {
                    if (result != PackageManager.PERMISSION_GRANTED) {
                        allPermissionsGranted = false;
                        break;
                    }
                }

                if (allPermissionsGranted) {
                    locationPermissionGranted = true;
                    initializeMap();
                } else {
                    Toast.makeText(this, "Location permission is required to show directions", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    // MapView lifecycle methods
    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }
}